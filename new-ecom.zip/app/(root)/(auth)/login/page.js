import { getUser } from "@/actions/authActions";
import Login from "@/components/auth/login";

const LoginPage = async() => {


    return (
        <Login />
    );
};

export default LoginPage;